const CACHE='fitflow-v26';
const ASSETS=['./','./index.html','./manifest.json','./assets/fitflow-180.png','./assets/fitflow-192.png','./assets/fitflow-512.png','./assets/fitdaily-badge.png'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{ if(e.request.method!=='GET') return; e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return res}).catch(()=>caches.match('./index.html')))); });
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{for(const c of cs){if('focus'in c)return c.focus()}return self.clients.openWindow('./')}));});
self.addEventListener('push',e=>{const d=e.data?e.data.json():{};e.waitUntil(self.registration.showNotification(d.title||'FitFlow',{body:d.body||'It is time for your routine.',silent:false,requireInteraction:true,vibrate:[250,150,250,150,500],icon:'./assets/fitflow-192.png',badge:'./assets/fitflow-192.png',tag:d.tag||'fitflow-reminder'}));});
