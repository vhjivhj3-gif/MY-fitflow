# MyFitFlow Android Project

Ready-to-build Android Studio project for MyFitFlow.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose a connected Android phone or emulator.
4. Run the `app` configuration, or use **Build > Generate App Bundle / APK > Generate APKs**.

Application ID: `com.myfitflow.app`
Minimum Android: 6.0 (API 23)
Target Android: API 35

The current MyFitFlow web app is packaged locally inside `app/src/main/assets/`, so the core app does not require Chrome or an internet connection to open.

Note: Android system-level scheduled notifications that fire while the app process is fully stopped require a native AlarmManager/WorkManager notification layer. The current web reminder logic remains available inside the packaged app.
